from django.shortcuts import render,redirect ,get_object_or_404
from blogs.forms import *
from blogs.models import *
from django.http import JsonResponse
from django.contrib.auth.hashers import check_password

def addpost(request): #to add new post here
    if request.method=='POST':
        form=Article_Content_Forms(request.POST)
        if form.is_valid():
            form.save()
            return redirect('main')
    else:
        form=Article_Content_Forms()
    return render(request,'dataadd.html',{'form':form})

def main(request): #main page to view all posts
    datacontent=ArticleContents.objects.all()
    return render(request,'main.html',{'datacontent':datacontent})

def content_view(request ,id): #to read the full content of a post
    data= get_object_or_404(ArticleContents,id=id)
    datacontent=ArticleContents.objects.all()
    return render(request,'contents.html',{'data':data,'datacontent':datacontent})

# def  del_content(request,id): #delete a post
#     data=get_object_or_404(ArticleContents,id=id)
#     data.delete()
#     return redirect('main')

def del_content(request, id):  # Expect 'id' as the argument
    data = get_object_or_404(ArticleContents, id=id)  # Get the content by id
    if request.method == 'POST':
        entered_code = request.POST.get('confirmation_code')
        if entered_code == "1234":  # Replace with your desired code
            data.delete()  # Delete the content
        # Regardless of whether the code is correct or not, redirect to main page
        return redirect('main')
    return render(request, 'delete_confirmation.html', {'data': data})

def signup(request):

    if request.method=='POST':
        sforms=Author_Details_Forms(request.POST)
        if sforms.is_valid():
            sforms.save()
            return redirect('login')
    else:
        sforms=Author_Details_Forms()
    return render(request,'signup.html',{'sforms':sforms})

def login(request):
    if request.method == 'POST':
        authorname = request.POST.get('authorname')  # Get username from the form
        password = request.POST.get('password')
        try:
            user = AuthorDetails.objects.get(authorname=authorname, password=password)
            return redirect('main')
        except AuthorDetails.DoesNotExist:
            return render(request, 'login.html')
    else:
        return render(request, 'login.html')
    
def terms(request):
    return render(request,'terms.html')

def contact(request):
    return render(request,'contact.html')