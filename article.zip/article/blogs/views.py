from django.shortcuts import render,redirect ,get_object_or_404
from blogs.forms import *
from blogs.models import *

# Create your views here.
def addpost(request):
    if request.method=='POST':
        form=Article_Content_Forms(request.POST)
        if form.is_valid():
            form.save()
            return redirect('main')
    else:
        form=Article_Content_Forms()
    return render(request,'dataadd.html',{'form':form})


def main(request):
    datacontent=ArticleContents.objects.all()
    return render(request,'main.html',{'datacontent':datacontent})

def content_view(request ,id):
    data= get_object_or_404(ArticleContents,id=id)
    datacontent=ArticleContents.objects.all()
    return render(request,'contents.html',{'data':data,'datacontent':datacontent})

def  del_content(request,id):
    data=get_object_or_404(ArticleContents,id=id)
    data.delete()
    return redirect('main')