from django.db import models

# Create your models here.

class ArticleContents(models.Model):
    title=models.CharField(max_length=100)
    subtitle=models.CharField(max_length=100)
    content=models.TextField(max_length=5000)
    author=models.CharField(max_length=100)
    
    class Meta:
        db_table='Article'