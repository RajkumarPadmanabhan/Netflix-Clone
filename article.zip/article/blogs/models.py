from django.db import models

# Create your models here.

class ArticleContents(models.Model):
    title=models.CharField(max_length=100)
    subtitle=models.CharField(max_length=100)
    content=models.TextField(max_length=5000)
    author=models.CharField(max_length=100)
    
    
    class Meta:
        db_table='Article'

class AuthorDetails(models.Model):
    GENDER_CHOICES = [
        ('M', 'Male'),
        ('F', 'Female'),
        ('O', 'Other'),
    ]
    
    COUNTRY_CHOICES = [
        ('USA', 'United States'),
        ('CAN', 'Canada'),
        ('IND', 'India'),
        ('AUS', 'Australia'),
        ('UK', 'United Kingdom'),
        ('GER', 'Germany'),
        ('FRA', 'France'),
        ('CHN', 'China'),
        ('JPN', 'Japan'),
        ('BRA', 'Brazil'),
        ('RSA', 'South Africa'),
        ('NZ', 'New Zealand'),
        ('ITA', 'Italy'),
        ('MEX', 'Mexico'),
        ('RUS', 'Russia'),
    ]

    authorname = models.CharField(max_length=50)
    password = models.CharField(max_length=6)
    gender = models.CharField(max_length=1, choices=GENDER_CHOICES, default='M')
    country = models.CharField(max_length=3, choices=COUNTRY_CHOICES, default='IND')
    last_login = models.DateTimeField(auto_now=True)
    class Meta:
        db_table='Author-Data'
