from django import forms
from .models import *

class Article_Content_Forms(forms.ModelForm):
    class Meta:
        model=ArticleContents
        fields='__all__'