from django import forms
from .models import *

class Article_Content_Forms(forms.ModelForm):
    class Meta:
        model=ArticleContents
        fields='__all__'

class Author_Details_Forms(forms.ModelForm):
    class Meta:
        model=AuthorDetails
        fields='__all__'

class PasswordForm(forms.Form):
    password = forms.CharField(widget=forms.PasswordInput, label="Enter your password")